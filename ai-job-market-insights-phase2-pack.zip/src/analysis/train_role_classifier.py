
from __future__ import annotations
import argparse
import os
import re
import joblib
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.metrics import classification_report, confusion_matrix
import matplotlib.pyplot as plt

ROLE_PATTERNS = [
    ("data_scientist", re.compile(r"(?i)\bdata\s*scientist\b")),
    ("ml_engineer", re.compile(r"(?i)\b(ml|machine\s*learning)\s*engineer\b")),
    ("data_engineer", re.compile(r"(?i)\bdata\s*engineer\b")),
    ("risk_analyst", re.compile(r"(?i)\b(risk|credit)\s*(data\s*)?analyst\b")),
    ("quant_researcher", re.compile(r"(?i)\bquant(itative)?\s*(researcher|analyst)?\b")),
    ("mlops_engineer", re.compile(r"(?i)\bmlops\s*engineer\b")),
    ("cv_engineer", re.compile(r"(?i)\b(computer\s*vision|cv)\s*engineer\b")),
]

def infer_role_label(title: str) -> str:
    if not isinstance(title, str):
        return "other"
    for label, pat in ROLE_PATTERNS:
        if pat.search(title):
            return label
    return "other"

def main():
    ap = argparse.ArgumentParser(description="Train baseline role classifier from cleaned_text.")
    ap.add_argument("--in", dest="in_path", required=True)
    ap.add_argument("--out-model", dest="out_model", required=True)
    ap.add_argument("--out-report", dest="out_report", required=True)
    ap.add_argument("--out-cm", dest="out_cm", required=True)
    args = ap.parse_args()

    df = pd.read_parquet(args.in_path)
    if "cleaned_text" not in df.columns or "title" not in df.columns:
        raise SystemExit("Input must contain 'cleaned_text' and 'title'")

    df["role_label"] = [infer_role_label(t) for t in df["title"]]
    df = df[df["role_label"] != "other"].reset_index(drop=True)
    if len(df) < 20:
        raise SystemExit("Not enough labeled samples after filtering. Add more data.")

    X = df["cleaned_text"].tolist()
    y = df["role_label"].tolist()

    pipe = Pipeline([
        ("tfidf", TfidfVectorizer(max_features=25000, ngram_range=(1,2))),
        ("clf", LogisticRegression(max_iter=200))
    ])
    pipe.fit(X, y)

    y_pred = pipe.predict(X)
    report = classification_report(y, y_pred)
    os.makedirs(os.path.dirname(args.out_report), exist_ok=True)
    with open(args.out_report, "w", encoding="utf-8") as f:
        f.write(report)

    labels = sorted(sorted(set(y)))
    cm = confusion_matrix(y, y_pred, labels=labels)
    plt.figure(figsize=(6, 5))
    plt.imshow(cm, interpolation="nearest")
    plt.title("Confusion Matrix (train-eval quick baseline)")
    plt.xticks(range(len(labels)), labels, rotation=45, ha="right")
    plt.yticks(range(len(labels)), labels)
    for i in range(len(labels)):
        for j in range(len(labels)):
            plt.text(j, i, cm[i, j], ha="center", va="center")
    plt.tight_layout()
    os.makedirs(os.path.dirname(args.out_cm), exist_ok=True)
    plt.savefig(args.out_cm, dpi=160)
    plt.close()

    os.makedirs(os.path.dirname(args.out_model), exist_ok=True)
    joblib.dump(pipe, args.out_model)

    print("Saved:")
    print(" - model:", args.out_model)
    print(" - report:", args.out_report)
    print(" - confusion matrix:", args.out_cm)

if __name__ == "__main__":
    main()
