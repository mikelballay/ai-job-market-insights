
from __future__ import annotations
import argparse
import re
import pandas as pd
from typing import List, Dict, Set

SKILL_SYNONYMS = {
    "python": ["python"],
    "sql": ["sql"],
    "pandas": ["pandas"],
    "numpy": ["numpy"],
    "matplotlib": ["matplotlib"],
    "scikit-learn": ["scikit learn","sklearn","scikit-learn"],
    "pytorch": ["pytorch","py torch"],
    "tensorflow": ["tensorflow","tensor flow"],
    "spark": ["spark","pyspark"],
    "airflow": ["airflow","apache airflow"],
    "docker": ["docker"],
    "kubernetes": ["kubernetes","k8s","k8"],
    "mlflow": ["mlflow","ml flow"],
    "aws": ["aws","amazon web services"],
    "gcp": ["gcp","google cloud"],
    "azure": ["azure","microsoft azure"],
    "powerbi": ["powerbi","power bi"],
    "tableau": ["tableau"],
    "faiss": ["faiss"],
    "huggingface": ["huggingface","hugging face"],
    "transformers": ["transformers"],
    "opencv": ["opencv","open cv"],
    "nlp": ["nlp","natural language processing"],
    "computer-vision": ["computer vision","cv engineer","vision"],
    "risk-modeling": ["risk modeling","basel","ifrs9","credit risk","pd","lgd","ead"],
    "time-series": ["time series","tsfresh","arima","prophet"],
    "git": ["git","github","gitlab"],
    "linux": ["linux","bash","shell scripting","shell"],
}

def compile_patterns(synonyms: Dict[str, List[str]]) -> Dict[str, re.Pattern]:
    pats: Dict[str, re.Pattern] = {}
    for canon, alts in synonyms.items():
        escaped = [re.escape(x) for x in alts]
        pat = r"(?i)(?<![\w\+\#])(" + "|".join(escaped) + r")(?![\w\+\#])"
        pats[canon] = re.compile(pat)
    return pats

def extract_line_skills(text: str, patterns: Dict[str, re.Pattern]) -> List[str]:
    if not isinstance(text, str) or not text:
        return []
    found: Set[str] = set()
    for canon, pat in patterns.items():
        if pat.search(text):
            found.add(canon)
    return sorted(found)

def main():
    ap = argparse.ArgumentParser(description="Extract skills to a list column 'skills'.")
    ap.add_argument("--in", dest="in_path", required=True)
    ap.add_argument("--out", dest="out_path", required=True)
    args = ap.parse_args()

    df = pd.read_parquet(args.in_path)
    if "cleaned_text" not in df.columns:
        raise SystemExit("Input parquet must contain 'cleaned_text'")

    patterns = compile_patterns(SKILL_SYNONYMS)
    df["skills"] = [extract_line_skills(t, patterns) for t in df["cleaned_text"].tolist()]
    df.to_parquet(args.out_path, index=False)
    print(f"Wrote features with skills to {args.out_path} (rows={len(df)})")

if __name__ == "__main__":
    main()
